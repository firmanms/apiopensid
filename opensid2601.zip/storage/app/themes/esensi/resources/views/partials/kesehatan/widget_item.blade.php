<div class="shadow  @@bg-color-300 rounded-lg py-2">
    <div class="p-4 flex flex-row">
        <div class="text-5xl">
            <i class="ion @@icon"></i>
        </div>
        <div class="flex-grow pl-6">
            <p class="text-gray-400">@@title</p>
            <p class="text-3xl">@@total</p>
        </div>
    </div>
</div>
