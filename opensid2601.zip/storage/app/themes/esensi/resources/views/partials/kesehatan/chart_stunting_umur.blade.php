<div class="grid grid-cols-1 lg:grid-cols-3 gap-5 container px-3 lg:px-5">
    <div id="chart_0_5"></div>
    <div id="chart_6_11"></div>
    <div id="chart_12_23"></div>
</div>
