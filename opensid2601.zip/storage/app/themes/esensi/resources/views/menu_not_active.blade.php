@extends('theme::template')

@section('layout')
    <section class="content">
        @include('theme::commons.404')
    </section>
@endsection
