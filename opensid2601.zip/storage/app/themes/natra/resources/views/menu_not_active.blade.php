@extends('theme::template')

@section('layout')
    @include('theme::partials.not_found')
@endsection
