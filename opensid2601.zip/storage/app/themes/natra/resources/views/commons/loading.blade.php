<div class="fa fa-circle-o-notch fa-spin fa-4x" role="status">
    <span class="sr-only">Loading...</span>
</div>
