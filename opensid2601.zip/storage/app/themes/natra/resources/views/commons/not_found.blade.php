<?php defined('BASEPATH') || exit('No direct script access allowed'); ?>

<div class="artikel" id="artikel-blank">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="error_page_content">
            <h1>404</h1>
            <h2>Maaf</h2>
            <h3>Halaman ini belum tersedia atau sedang dalam perbaikan</h3>
            <p class="wow fadeInLeftBig">
                <a href="<?= site_url() ?>">Silakan kembali lagi ke halaman Beranda</a>
            </p>
        </div>
    </div>
</div>
