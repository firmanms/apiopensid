<div class="business_category_left wow fadeInDown" id="artikel-blank">
    <div class="box box-warning box-solid">
        <div class="box-header">
            <h3 class="box-title">Maaf, belum ada data</h3>
        </div>
        <div class="box-body">
            <p>Belum ada artikel yang dituliskan dalam {{ $title }}</p>
            <p>Silakan kunjungi situs web kami dalam waktu dekat.</p>
        </div>
    </div>
</div>
