<div class="row mt-4">
    <div class="col-md-4 col-sm-12" id="chart_0_5"></div>
    <div class="col-md-4 col-sm-12" id="chart_6_11"></div>
    <div class="col-md-4 col-sm-12" id="chart_12_23"></div>
</div>
