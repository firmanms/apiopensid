<?php

defined('BASEPATH') || exit('No direct script access allowed');

include STORAGEPATH . 'app/template/lampiran/f-2.01/view.php';